#!/bin/bash

# Create a flag file to indicate initialization is complete
touch /var/lib/mysql/initialization-complete.flag
