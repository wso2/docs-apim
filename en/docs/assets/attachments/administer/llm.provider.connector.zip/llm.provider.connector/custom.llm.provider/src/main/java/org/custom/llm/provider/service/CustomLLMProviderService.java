/*
 * Copyright (c) 2024 WSO2 LLC. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 LLC. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.custom.llm.provider.service;

import org.osgi.service.component.annotations.Component;
import org.wso2.carbon.apimgt.api.model.LLMProvider;
import org.wso2.carbon.apimgt.api.*;

import java.util.List;
import java.util.Map;

/**
 * Custom implementation of the LLMProviderService interface for integrating a custom AI provider.
 * This service is responsible for handling the interaction between the API Management system and
 * the custom LLM (Large Language Model) provider.
 * The service allows for configuring request and response metadata, as well as defining the
 * specific type of the LLM provider and registering it within the system.
 */
@Component(
        name = "customAi.llm.provider.service",
        immediate = true,
        service = LLMProviderService.class
)
public class CustomLLMProviderService implements LLMProviderService {

    /**
     * Processes and returns response metadata received from the custom LLM provider response.
     * This method is used to modify or analyze the response received after calling the LLM provider.
     *
     * @param payload      The response payload returned by the LLM provider.
     * @param headers      The headers associated with the response.
     * @param queryParams  The query parameters used in the request.
     * @param metadataList List of LLMProviderMetadata objects related to the request/response.
     * @param metadataMap  Map containing metadata key-value pairs from the response.
     * @return The processed or modified metadata map to be used by the API Management system.
     * @throws APIManagementException If any errors occur while processing the response metadata.
     */
    @Override
    public Map<String, String> getResponseMetadata(String payload, Map<String, String> headers,
                                                   Map<String, String> queryParams,
                                                   List<LLMProviderMetadata> metadataList,
                                                   Map<String, String> metadataMap)
            throws APIManagementException {

        return metadataMap;
    }

    /**
     * Processes and returns request metadata to be sent to the custom LLM provider.
     * This method can be used to modify or enrich the metadata before sending a request to the LLM provider.
     *
     * @param payload      The request payload to be sent to the LLM provider.
     * @param headers      The headers to be sent with the request.
     * @param queryParams  The query parameters for the request.
     * @param metadataList List of LLMProviderMetadata objects related to the request.
     * @param metadataMap  Map containing metadata key-value pairs for the request.
     * @return The processed or modified metadata map to be sent to the LLM provider.
     * @throws APIManagementException If any errors occur while processing the request metadata.
     */
    @Override
    public Map<String, String> getRequestMetadata(String payload, Map<String, String> headers,
                                                  Map<String, String> queryParams,
                                                  List<LLMProviderMetadata> metadataList,
                                                  Map<String, String> metadataMap)
            throws APIManagementException {

        return metadataMap;
    }

    /**
     * Retrieves the connector type for the custom LLM provider.
     * This method should return the same connector type string that is configured in the admin portal
     * under "Connector Type for AI Vendor" when adding a new AI vendor.
     *
     * @return A string representing the type of the custom LLM provider.
     */
    @Override
    public String getType() {
        return "custom";
    }

    /**
     * Registers a new instance of the custom LLM provider.
     * This method is responsible for onboarding a new LLM provider programmatically at startup.
     * If onboarding through the admin portal, the method can return null.
     *
     * @param organization         The name of the organization onboarding the LLM provider.
     * @param apiDefinitionFilePath The path to the API definition file associated with the provider.
     * @return An LLMProvider instance representing the newly registered LLM provider,
     * or null if registered via the portal.
     * @throws APIManagementException If any errors occur during the registration process.
     */
    @Override
    public LLMProvider registerLLMProvider(String organization, String apiDefinitionFilePath)
            throws APIManagementException {
        return null;
    }
}
