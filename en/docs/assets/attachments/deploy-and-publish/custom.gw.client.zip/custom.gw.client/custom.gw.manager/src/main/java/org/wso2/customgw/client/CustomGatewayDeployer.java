/*
 * Copyright (c) 2025 WSO2 LLC. (http://www.wso2.org) All Rights Reserved.
 *
 * WSO2 LLC. licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.wso2.customgw.client;

import org.wso2.carbon.apimgt.api.APIManagementException;
import org.wso2.carbon.apimgt.api.model.API;
import org.wso2.carbon.apimgt.api.model.Environment;
import org.wso2.carbon.apimgt.api.model.GatewayAPIValidationResult;
import org.wso2.carbon.apimgt.api.model.GatewayDeployer;

import java.util.ArrayList;


/**
 * This class controls the API artifact deployments on the Custom API Gateway
 */
public class CustomGatewayDeployer implements GatewayDeployer {

    @Override
    public void init(Environment environment) throws APIManagementException {
        // todo create client objects to communicate with the external gateway
    }

    @Override
    public String getType() {
        return CustomGatewayConstants.CUSTOM_TYPE;
    }

    @Override
    public String deploy(API api, String externalReference) throws APIManagementException {
        // todo deploy API in custom gateway
        return null;
    }

    @Override
    public boolean undeploy(String externalReference) throws APIManagementException {
        // todo undeploy API in custom gateway
        return false;
    }

    @Override
    public GatewayAPIValidationResult validateApi(API api) throws APIManagementException {
        // todo perform initial validations before deploying API
        GatewayAPIValidationResult result = new GatewayAPIValidationResult();
        result.setValid(true);
        result.setErrors(new ArrayList<>());

        return result;
    }

    @Override
    public String getAPIExecutionURL(String externalReference) throws APIManagementException {
        // todo construct API execution URL
        return null;
    }

    @Override
    public void transformAPI(API api) throws APIManagementException {
        // todo apply any tranformation required to deploy API in custom gateway
    }
}
