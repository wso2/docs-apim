
### Setup Instruction ###

* Download the relevant WSO2 Integration Studio based on your operating system.
* Download the pre-packaged project creatio-test.zip.
* Open WSO2 Integration Studio and go to File -> Import.
* Select Existing WSO2 Projects into workspace under the WSO2 category, click Next, and then upload the prepackaged project.
* Replace Creatio instance Hostname, username passowrd in the creatioTestAPI.xml artifact
* Build the project - mvn clean install.
* Then deploy create a car file creatio-testCompositeExporter_1.0.0-SNAPSHOT.car (creatio-testCompositeExporter/target) and deploy into Micro Inetgrator instance. 
* CAR file Loctaion is micro-integrator/repository/deployment/server/carbonapps

### 1. Sample API for Auth for the creatio-test/auth API endpoint ### 

### Sample Request ### 
curl --location --request GET 'http://localhost:8290/creatio-test/auth' \
--header 'Accept: application/json;odata=verbose' \
--header 'Content-Type: application/json'

### Sample Response ###  

### Headers ### 

Cookie: UserName=83|117|112|101|114|118|105|115|111|114; BPMLOADER=stme4f4dc2cy3xa2pcq3adt4; .ASPXAUTH=51503F6C7F1BC2D13C1A0FF9F40E3115520F4E67A85EA204F62EE728439FCCC497C3A59CD56F057122BC0607F74A013913BEB0CE9C4C9E6D774009A34B1B7BB7DC3B41BF6C91EBC821C8EDE7F69BF7122B06F23503ED9125355040658475F915CAADE422057560E1776DD82D35181019334ADFE59312E030677695CCD37F45BCB8221D4CAC2DEFCF6630079DB16044320D4348EFC4724989D49D3F57B06B57B53FC1E9C320B1600A0298A2706B0C230800DB00DDF4CCE907CDB14E038CA0C8FC51400B9BF5120D897664841A5633BF965CCF1C696AA7229964E15A77BC79F66F27EBE12C211E8F178179641913C73EA956A293E1062D01853FDD145AF72FB5B8CD1D83C3E61B70FE44E7D8C661920824E0B3DDC1D3F99A4B28EC75E1AA7C886CC777723B5BA3A8B5312D512E12781F7FF87682CEFF7ABA2965327423D6B5247DB12144DD69CDD89E18E4208CF15160D001E0521D1DE48D542D418A8A56C8630825AF0DC2D366221208A166577A7937B5DC8F12EA0E81E5921B48205CEFD171B229E330E9AD096FB8E08B865E85D49FD1F17988E8C052B7E08DC4F837FCE6BF0E6BEA945AC06834A26972952C51DF0CB98CFCF6CB75CF9B16C22002385C5A00B47E1183D2EB4F233BBA5E2C542E03353DFC70132D95FC15FBCAFE2FD6F72410C8B08038A8F817736A73F09C08B84CEB0CD423DE4B; BPMCSRF=skwwQh5IGct3gqhJORwKW.
server: Microsoft-IIS/10.0
x-aspnet-version: 4.0.30319
Access-Control-Allow-Methods: GET
x-frame-options: SAMEORIGIN
Access-Control-Allow-Headers: 
strict-transport-security: max-age=63072000
set-cookie: .ASPXAUTH=51503F6C7F1BC2D13C1A0FF9F40E3115520F4E67A85EA204F62EE728439FCCC497C3A59CD56F057122BC0607F74A013913BEB0CE9C4C9E6D774009A34B1B7BB7DC3B41BF6C91EBC821C8EDE7F69BF7122B06F23503ED9125355040658475F915CAADE422057560E1776DD82D35181019334ADFE59312E030677695CCD37F45BCB8221D4CAC2DEFCF6630079DB16044320D4348EFC4724989D49D3F57B06B57B53FC1E9C320B1600A0298A2706B0C230800DB00DDF4CCE907CDB14E038CA0C8FC51400B9BF5120D897664841A5633BF965CCF1C696AA7229964E15A77BC79F66F27EBE12C211E8F178179641913C73EA956A293E1062D01853FDD145AF72FB5B8CD1D83C3E61B70FE44E7D8C661920824E0B3DDC1D3F99A4B28EC75E1AA7C886CC777723B5BA3A8B5312D512E12781F7FF87682CEFF7ABA2965327423D6B5247DB12144DD69CDD89E18E4208CF15160D001E0521D1DE48D542D418A8A56C8630825AF0DC2D366221208A166577A7937B5DC8F12EA0E81E5921B48205CEFD171B229E330E9AD096FB8E08B865E85D49FD1F17988E8C052B7E08DC4F837FCE6BF0E6BEA945AC06834A26972952C51DF0CB98CFCF6CB75CF9B16C22002385C5A00B47E1183D2EB4F233BBA5E2C542E03353DFC70132D95FC15FBCAFE2FD6F72410C8B08038A8F817736A73F09C08B84CEB0CD423DE4B; path=/; secure; HttpOnly
set-cookie: BPMCSRF=skwwQh5IGct3gqhJORwKW.; path=/; secure
set-cookie: SsoSessionId=83eb23f2-7589-4d0e-9c0e-e03353d4194a; path=/; secure
set-cookie: UserName=83|117|112|101|114|118|105|115|111|114; expires=Wed, 09-Nov-2022 07:13:53 GMT; path=/; secure; HttpOnly
x-content-type-options: nosniff
BPMCSRF: skwwQh5IGct3gqhJORwKW.
x-powered-by: ASP.NET
content-security-policy-report-only: style-src-attr 'unsafe-inline' 'self' ; img-src data: *.tile.openstreetmap.org https://*.creatio.com http://*.creatio.com https://*.bpmonline.com http://*.bpmonline.com 'self' ; prefetch-src 'self' ; script-src 'self' 'unsafe-eval' 'unsafe-inline' ; style-src 'self' 'unsafe-inline' ; script-src-attr 'self' 'unsafe-inline' ; connect-src https://*.creatio.com http://*.creatio.com ws://dev-telecom.creatio.com https://*.bpmonline.com wss://*.bpmonline.com:* wss://dev-telecom.creatio.com http://*.bpmonline.com 'self' ; font-src https://fonts.gstatic.com data: 'self' ; manifest-src 'self' ; worker-src 'self' ; frame-src http://*.bpmonline.com 'self' http://*.creatio.com https://*.creatio.com https://*.bpmonline.com ; script-src-elem 'unsafe-inline' connect.facebook.net/en_US/all.js 'self' ; child-src http://*.creatio.com 'self' https://*.creatio.com ; frame-ancestors 'self' ; media-src 'self' ; style-src-elem https://fonts.googleapis.com 'self' 'unsafe-inline' ; object-src 'none' ; form-action 'self' ; report-uri https://dev-telecom.creatio.com/0/ServiceModel/CspViolationService.svc/SaveCspViolationData;
content-type: application/json; charset=utf-8
location: /0
x-terrasoft-userculture: en-US
cache-control: private
Content-Type: application/json; charset=utf-8
Date: Mon, 10 Oct 2022 06:13:31 GMT
Transfer-Encoding: chunked
Connection: keep-alive

### Body ### 
 {"Code":0,"Message":"","Exception":null,"PasswordChangeUrl":null,"RedirectUrl":null}


### 2. Account Create for the creatio-test/account API endpoint ### 

### Sample Request ### 
curl --location --request POST 'http://localhost:8290/creatio-test/account' \
--header 'Accept: application/json;odata=verbose' \
--header 'Content-Type: application/json' \
--header 'ForceUseSession: true' \
--header 'BPMCSRF: skwwQh5IGct3gqhJORwKW.' \
--data-raw '{
    "Name": "API Test",
    "ProcessListeners": 0,
    "Code": "73",
    "Phone": "+1 206 480 3801",
    "AdditionalPhone": "+1 206 480 4495",
    "Fax": "",
    "Web": "www.infocom-global.com",
    "Address": "48 Pilgrim Street",
    "Notes": ""
}'

### Sample Response- from  Creatio ### 

{
    "@odata.context": "https://dev-telecom.creatio.com/0/odata/$metadata#Account/$entity",
    "Id": "f538e4d2-1dfb-4ff1-b816-4f63bcd6c47c",
    "Name": "API Test",
    "OwnerId": "410006e1-ca4e-4502-a9ec-e54d922d2c00",
    "CreatedOn": "2022-10-10T06:16:26.299453Z",
    "CreatedById": "410006e1-ca4e-4502-a9ec-e54d922d2c00",
    "ModifiedOn": "2022-10-10T06:16:26.299453Z",
    "ModifiedById": "410006e1-ca4e-4502-a9ec-e54d922d2c00",
    "ProcessListeners": 0,
    "OwnershipId": "00000000-0000-0000-0000-000000000000",
    "PrimaryContactId": "00000000-0000-0000-0000-000000000000",
    "ParentId": "00000000-0000-0000-0000-000000000000",
    "IndustryId": "00000000-0000-0000-0000-000000000000",
    "Code": "73",
    "TypeId": "00000000-0000-0000-0000-000000000000",
    "Phone": "+1 206 480 3801",
    "AdditionalPhone": "+1 206 480 4495",
    "Fax": "",
    "Web": "www.infocom-global.com",
    "AddressTypeId": "00000000-0000-0000-0000-000000000000",
    "Address": "48 Pilgrim Street",
    "CityId": "00000000-0000-0000-0000-000000000000",
    "RegionId": "00000000-0000-0000-0000-000000000000",
    "Zip": "",
    "CountryId": "00000000-0000-0000-0000-000000000000",
    "AccountCategoryId": "00000000-0000-0000-0000-000000000000",
    "EmployeesNumberId": "00000000-0000-0000-0000-000000000000",
    "AnnualRevenueId": "00000000-0000-0000-0000-000000000000",
    "Notes": "",
    "Logo@odata.mediaEditLink": "Account(f538e4d2-1dfb-4ff1-b816-4f63bcd6c47c)/Logo",
    "Logo@odata.mediaReadLink": "Account(f538e4d2-1dfb-4ff1-b816-4f63bcd6c47c)/Logo",
    "Logo@odata.mediaContentType": "application/octet-stream",
    "AlternativeName": "",
    "GPSN": "",
    "GPSE": "",
    "AccountLogoId": "00000000-0000-0000-0000-000000000000",
    "AUM": "",
    "Completeness": 0,
    "MTCMBlacklistId": "00000000-0000-0000-0000-000000000000",
    "MTCMBlackListRemarks": "",
    "MTCMRiskCategoryId": "00000000-0000-0000-0000-000000000000",
    "MTCMCountryId": "00000000-0000-0000-0000-000000000000",
    "MTCMBRN": "",
    "MTCMParentName": "",
    "MTCMParentId": "",
    "MTCMVATNumber": "",
    "MTCMVATApplicableId": "00000000-0000-0000-0000-000000000000",
    "MTCMStatus": false,
    "MTCMCreationDate": "0001-01-01T00:00:00Z",
    "MTCMAccountStatusId": "3ecd6cd4-50af-4f4e-9e50-b4b7e04f0530",
    "MTCMInfluencerStatusId": "00000000-0000-0000-0000-000000000000",
    "MTCMTemporaryAM": false,
    "MTCMSegmentationId": "00000000-0000-0000-0000-000000000000",
    "MTCMProfileAccountId": "00000000-0000-0000-0000-000000000000",
    "MTCMEbillId": "00000000-0000-0000-0000-000000000000",
    "MTCMReviewStatusId": "00000000-0000-0000-0000-000000000000",
    "MTCMRevenueGenerated": 0,
    "MTCMPotentialRevenue": 0,
    "MTCMCustomerCategoryId": "00000000-0000-0000-0000-000000000000",
    "MTCMBudget": 0,
    "MTCMTarget": 0,
    "MTLAvailableLoyaltyPoints": 0,
    "MTCMAdditionalDeposit": 0,
    "MTCMInitialDeposit": 0,
    "MTCMTotalDeposit": 0,
    "MTCMContractStartDate": "0001-01-01T00:00:00Z",
    "MTCMContractEndDate": "0001-01-01T00:00:00Z",
    "MTCMTechnologyId": "00000000-0000-0000-0000-000000000000",
    "MTCMIMEINumber": "",
    "MTCMSTBType": "",
    "MTCMMDF": "",
    "MTCMCabinet": "",
    "MTCMFDP": "",
    "MTCMActivatedViaId": "00000000-0000-0000-0000-000000000000",
    "MTCMMobileMoneyAccount": "",
    "MTCMSimKitNumber": "",
    "MTCMSimActivationDate": "0001-01-01T00:00:00Z",
    "MTCMIMSINumber": "",
    "MTCMSimCategoryId": "00000000-0000-0000-0000-000000000000",
    "MTCMSimNumber": "",
    "MTCMCardNumber": "",
    "MTCMServiceNumberCategoryId": "00000000-0000-0000-0000-000000000000",
    "MTCMResTokenNo": "",
    "MTCMBusinessTypeId": "00000000-0000-0000-0000-000000000000",
    "MTCMServiceTypeId": "00000000-0000-0000-0000-000000000000",
    "MTCMBillCyclePeriodId": "00000000-0000-0000-0000-000000000000",
    "MTCMSubServiceTypeId": "00000000-0000-0000-0000-000000000000",
    "MTCMServiceNumber": "",
    "MTCMServiceStatusId": "00000000-0000-0000-0000-000000000000",
    "MTCMRegistrationDate": "0001-01-01T00:00:00Z",
    "MTCMDeactivationDate": "0001-01-01T00:00:00Z",
    "PriceListId": "00000000-0000-0000-0000-000000000000",
    "MTCMBillCycleRequestId": "00000000-0000-0000-0000-000000000000",
    "MTCMCreditDays": "",
    "MTCMCreditLimit": "",
    "MTCMAccountId": "",
    "MTCMisBillByEmail": false,
    "MTCMisBillByFax": false,
    "MTCMisBillByPost": false,
    "MTCMisBillBySMS": false,
    "MTCMisDunningApplicable": false,
    "MTCMemail": "",
    "MTCMFaxNumber": "",
    "MTCMMobileNumber": "",
    "MTCMPreferredLanguage": "",
    "MTCMPrefferedCurrency": "",
    "MTCMRegistrationDateinProfile": "0001-01-01T00:00:00Z",
    "MTCMTaxApplicableId": "00000000-0000-0000-0000-000000000000",
    "MTCMProfileId": "00000000-0000-0000-0000-000000000000",
    "MTLDefaultLoyaltyPercentage": 0,
    "MTLOverrideValue": 0,
    "MTLAgreedAirtimeRs": 0,
    "MTLEnrollmentDate": "0001-01-01T00:00:00Z",
    "MTLExpiryDate": "0001-01-01T00:00:00Z",
    "MTLLoyaltyCategoryId": "00000000-0000-0000-0000-000000000000",
    "MTLIsEnrolled": false,
    "MTLLoyaltyStatusId": "00000000-0000-0000-0000-000000000000",
    "MTLContractPeriodId": "00000000-0000-0000-0000-000000000000",
    "MTLDeEnrolledDate": "0001-01-01T00:00:00Z",
    "MTCMVerticalLeadId": "00000000-0000-0000-0000-000000000000",
    "MTCMVerticalId": "00000000-0000-0000-0000-000000000000",
    "MTCMTotalUnbilledAmount": 0,
    "MTCMUnbilledUsageAmount": 0,
    "MTCMFloat1": 0,
    "MTCMParentGroupId": "00000000-0000-0000-0000-000000000000",
    "MTLCurrentLoyaltyPoints": 0,
    "MTLTotalTransactionAmount": 0,
    "MTFLob": "",
    "MTFUnbilledUsgAmt": 0,
    "MTFUnbilledAdvRental": 0,
    "MTFTotalDeposit": 0,
    "MTFTotalUnbilledAmount": 0,
    "MTLTransactions": 0,
    "MTLTotalBillingTransactions": 0,
    "MTLAdditionalNotesLoyalty": "",
    "MTLAvailableLoyaltyPointsAccounts": 0,
    "MTLLoyaltyContractId": "00000000-0000-0000-0000-000000000000",
    "MTLPreviousMonthTransactionsTotal": 0,
    "MTCMCreatedOnInClm": "0001-01-01T00:00:00Z",
    "MTCMmodifiedOnInClm": "0001-01-01T00:00:00Z",
    "MTCUpdatedFromMAL": false,
    "MTPBNoOfEmployees": 0,
    "MTLContractTypeFilterId": "4ad8d1d2-8d39-4b54-8017-afec75dcd9c3",
    "MTUB8901UMBPCounted": false,
    "MTUBLastTransactionDate": "2022-01-01T00:00:00Z",
    "CLMNumberofEmployees": 0,
    "MTAPAccountTechnologyStrategistId": "00000000-0000-0000-0000-000000000000",
    "MTAPSummaryAbouttheCustomer": "",
    "MTAPHighLevelTopologyImageId": "00000000-0000-0000-0000-000000000000",
    "MTCYTDRevenue": 0,
    "MTCOutstanding": 0,
    "MTCRevenueforpastfinancialyear": 0,
    "MTCRevenuegeneratedfromMobileservices": 0,
    "MTCNumberofreach": 0,
    "MTCNumberofkickoffmeetings": 0,
    "MTCNumberofDesktop": 0,
    "MTCNumberofOnPremServers": 0,
    "MTCNumberofCloudServers": 0,
    "MTCNumberofDisconnection": 0,
    "MTLTotalConsumed": 0
}
