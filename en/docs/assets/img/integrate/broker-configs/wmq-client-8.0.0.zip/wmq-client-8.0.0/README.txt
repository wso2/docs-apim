Date : 14/06/2015
Email : support@wso2.com 

Instructions to Install IBM MQ 8.0.0.2 client jars to WSO2 ESB/Integrator.
===============================================================

Prerequisites
-------------

1) Install Java and Set JAVA_HOME environment variable (Prerequisites for Maven) 
2) Install Apache Maven 3.X and Set MAVEN_HOME and M2 environment variables
3) IBM MQ 8.0.0.2 Java libraries (jars)

Build Instructions
------------------

1) Copy following jars from <IBM MQ 8.0.0.2 installation Directory>\java\lib directory to wmq-client\lib .
	*	com.ibm.mq.allclient.jar
	*	fscontext.jar
	*	jms.jar
	*	providerutil.jar

2) Build wmq-client project using Apache Maven with following command line command

	mvn clean install

	
Installing IBM MQ Client jars to WSO2 ESB/Integrator
——————————————————————————

1) Stop WSO2 server, if it is already running. 
2) (If present) Remove Old IBM MQ client jars from <WSO2_Home>\repository\components\dropins and <WSO2_Home>\repository\components\lib
3) Copy wmq-client\target\wmq-client-8.0.0.2.jar to <WSO2_Home>\repository\components\dropins
4) Copy jta.jar to <WSO2_Home>\repository\components\lib
5) Remove following line from <WSO2_Home>\repository\conf\etc\launch.ini

	javax.jms,\

6) [Important] Regenerate .bindings file with following property.

		Provider Version : 8
		
7) Replace old .bindings file with new .bindings file.  	
8) Start ESB server. 


--- End of Document. ----